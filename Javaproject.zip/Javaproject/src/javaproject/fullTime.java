/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaproject;

/**
 *
 * @author macstudent
 */
public class fullTime extends Employee implements IDisplay{
    
    
    private double commission;
    private double fixedSalary;
    private double totalSalary;
    
 

    public fullTime() {
        
        
       
    }
    
    public fullTime(double commission, double fixedSalary) {
        this.commission = commission;
        this.fixedSalary = fixedSalary;
    }

    public fullTime(int employeeID, String employeeName, double commission, double fixedSalary) {
        super(employeeID, employeeName);
        this.commission = commission;
        this.fixedSalary = fixedSalary;
    }

    public double getCommission() {
        return commission;
    }

    public void setCommission(double commission) {
        this.commission = commission;
    }

    public double getFixedSalary() {
        return fixedSalary;
    }

    public void setFixedSalary(double fixedSalary) {
        this.fixedSalary = fixedSalary;
    }

    public double getTotalSalary() {
        return totalSalary;
    }
    
    @Override
    public void calculateSalary()
     {
         this.totalSalary = this.fixedSalary + this.commission;
     }

    @Override
    public String toString() {
        return "FullTime{" + "commission=" + commission + ", fixedSalary=" + fixedSalary + ", totalSalary=" + totalSalary + '}';
    }

    @Override
    public String displayData()
    {
        return super.toString() + "\n" + this.toString();
    }    
    
    
}
