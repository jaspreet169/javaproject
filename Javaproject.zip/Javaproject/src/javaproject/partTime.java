/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaproject;

/**
 *
 * @author macstudent
 */
public class partTime {private int noOfHours;
    private double rate;
    private double totalSalary;

   
    public partTime() {
        super();
    }

    public partTime(int noOfHours, double rate) {
        this.noOfHours = noOfHours;
        this.rate = rate;
    }

    public partTime(int employeeID, String employeeName, int noOfHours, double rate) {
        super(employeeID, employeeName);
        this.noOfHours = noOfHours;
        this.rate = rate;
    }

    public int getNoOfHours() {
        return noOfHours;
    }

    public void setNoOfHours(int noOfHours) {
        this.noOfHours = noOfHours;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
    
     public double getTotalSalary() {
        return totalSalary;
    }

    @Override
    public void calculateSalary()
    {
        this.totalSalary = this.rate * this.noOfHours;
    }

    @Override
    public String toString() {
        return "PartTime{" + "noOfHours=" + noOfHours + ", rate=" + rate + ", totalSalary=" + totalSalary + '}';
    }
    
    @Override
    public String displayData()
    {
        return super.toString() + "\n" + this.toString();
    }
    
    public void display()
    {
           System.out.println(" Part timeHello from default interface method");
    }
     
     
    
}
